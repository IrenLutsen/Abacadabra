/* Abacadabra — інтерактивність лендінгу */
(function () {
  var en = document.documentElement.lang === "en";
  var T = en ? {
    task: "Try to set the number", done: "Well done — that's it!",
    sending: "Sending…", ok: "Thank you! We'll message you within one working day.",
    okBooking: "Thank you! Opening the calendar so you can pick a time…",
    err: "Something went wrong. Please message us on WhatsApp or Telegram.",
    notSet: "The form isn't connected yet. Please message us on WhatsApp or Telegram.",
    rods: ["Hundreds", "Tens", "Ones"],
    regular: "1 lesson a week · about 10 weeks", intensive: "2 lessons a week · about 5 weeks"
  } : {
    task: "Спробуйте покласти число", done: "Чудово — вийшло!",
    sending: "Надсилаємо…", ok: "Дякуємо! Ми напишемо вам протягом одного робочого дня.",
    okBooking: "Дякуємо! Відкриваємо календар, щоб ви обрали зручний час…",
    err: "Щось пішло не так. Напишіть нам, будь ласка, у WhatsApp або Telegram.",
    notSet: "Форму ще не підключено. Напишіть нам, будь ласка, у WhatsApp або Telegram.",
    rods: ["Сотні", "Десятки", "Одиниці"],
    regular: "1 заняття на тиждень · ≈ 10 тижнів", intensive: "2 заняття на тиждень · ≈ 5 тижнів"
  };

  /* Бургер-меню */
  var burger = document.querySelector(".burger");
  var nav = document.getElementById("nav");
  if (burger && nav) {
    burger.addEventListener("click", function () {
      var open = burger.getAttribute("aria-expanded") === "true";
      burger.setAttribute("aria-expanded", String(!open));
      nav.classList.toggle("is-open", !open);
    });
    nav.addEventListener("click", function (e) {
      if (e.target.tagName === "A") { burger.setAttribute("aria-expanded", "false"); nav.classList.remove("is-open"); }
    });
  }

  /* Перемикач «Звичайний / Інтенсив» */
  var toggleBtns = document.querySelectorAll("[data-mode]");
  toggleBtns.forEach(function (b) {
    b.addEventListener("click", function () {
      var mode = b.getAttribute("data-mode");
      toggleBtns.forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
      document.querySelectorAll(".price__mode").forEach(function (el) { el.textContent = T[mode]; });
      var hidden = document.querySelector('[name="intensive"]');
      if (hidden) hidden.value = mode === "intensive" ? "yes" : "no";
    });
  });

  /* Абакус-демо: 3 спиці, верхня кісточка = 5, нижні = 1 */
  var root = document.getElementById("abacus");
  if (root) {
    var rods = [{ u: false, l: 0 }, { u: false, l: 0 }, { u: false, l: 0 }];
    var target = 0;
    var valEl = document.getElementById("abacus-value");
    var taskEl = document.getElementById("abacus-task");
    var okEl = document.getElementById("abacus-ok");
    var sp = function () { var s = document.createElement("div"); s.className = "spacer"; return s; };
    var bead = function (on, label, fn) {
      var b = document.createElement("button");
      b.type = "button"; b.className = "bead" + (on ? " bead--on" : "");
      b.setAttribute("aria-label", label); b.setAttribute("aria-pressed", String(on));
      b.addEventListener("click", fn); return b;
    };
    var value = function () { return rods.reduce(function (a, r) { return a * 10 + (r.u ? 5 : 0) + r.l; }, 0); };
    var render = function () {
      var inner = document.createElement("div"); inner.className = "abacus__inner";
      rods.forEach(function (r, k) {
        var rod = document.createElement("div"); rod.className = "rod";
        var up = document.createElement("div"); up.className = "rod__upper";
        var ub = bead(r.u, T.rods[k] + " — 5", function () { r.u = !r.u; render(); });
        if (r.u) { up.appendChild(sp()); up.appendChild(ub); } else { up.appendChild(ub); up.appendChild(sp()); }
        var beam = document.createElement("div"); beam.className = "rod__beam";
        var low = document.createElement("div"); low.className = "rod__lower";
        for (var i = 0; i < 4; i++) (function (i) {
          if (i === r.l) low.appendChild(sp());
          low.appendChild(bead(i < r.l, T.rods[k] + " — 1", function () { r.l = i < r.l ? i : i + 1; render(); }));
        })(i);
        if (r.l === 4) low.appendChild(sp());
        var lab = document.createElement("div"); lab.className = "rod__label"; lab.textContent = T.rods[k];
        rod.appendChild(up); rod.appendChild(beam); rod.appendChild(low); rod.appendChild(lab);
        inner.appendChild(rod);
      });
      root.innerHTML = ""; root.appendChild(inner);
      var v = value(); valEl.textContent = v;
      okEl.textContent = target && v === target ? T.done : "";
    };
    var pool = [3, 6, 8, 9, 14, 27, 45, 63, 108, 259];
    var next = function () {
      var t; do { t = pool[Math.floor(Math.random() * pool.length)]; } while (t === target);
      target = t; taskEl.textContent = T.task + ": " + target; render();
    };
    document.getElementById("abacus-new").addEventListener("click", next);
    document.getElementById("abacus-reset").addEventListener("click", function () { rods.forEach(function (r) { r.u = false; r.l = 0; }); render(); });
    next();
  }

  /* Поява блоків */
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("is-in"); io.unobserve(e.target); } });
    }, { rootMargin: "0px 0px -8% 0px" });
    reveals.forEach(function (el) { io.observe(el); });
  } else { reveals.forEach(function (el) { el.classList.add("is-in"); }); }

  /* Плаваюча кнопка ховається на першому екрані й біля форми */
  var fl = document.querySelector(".float-cta");
  var signup = document.getElementById("signup");
  var hero = document.querySelector(".hero");
  if (fl && signup && "IntersectionObserver" in window) {
    var state = { hero: true, form: false };
    var upd = function () { fl.classList.toggle("is-hidden", state.hero || state.form); };
    new IntersectionObserver(function (es) { state.form = es[0].isIntersecting; upd(); }).observe(signup);
    if (hero) new IntersectionObserver(function (es) { state.hero = es[0].isIntersecting; upd(); }, { threshold: .35 }).observe(hero);
  }

  /* Cookie-банер (сайт не використовує рекламних cookies; зберігаємо лише вибір) */
  var ck = document.getElementById("cookie");
  if (ck) {
    var stored = null;
    try { stored = localStorage.getItem("abc_cookie"); } catch (e) {}
    if (!stored) ck.classList.add("is-visible");
    ck.querySelectorAll("[data-cookie]").forEach(function (b) {
      b.addEventListener("click", function () {
        try { localStorage.setItem("abc_cookie", b.getAttribute("data-cookie")); } catch (e) {}
        ck.classList.remove("is-visible");
      });
    });
  }

  /* Форма запису */
  var form = document.getElementById("lead-form");
  if (form) {
    var tz = form.querySelector('[name="timezone"]');
    try { if (tz && !tz.value) tz.value = Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) {}
    var src = form.querySelector('[name="page"]'); if (src) src.value = location.href;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var st = document.getElementById("form-status");
      if (form.action.indexOf("YOUR_FORM_ID") !== -1) { st.textContent = T.notSet; return; }
      st.textContent = T.sending;
      fetch(form.action, { method: "POST", body: new FormData(form), headers: { Accept: "application/json" } })
        .then(function (r) {
          if (!r.ok) throw new Error();
          var booking = form.getAttribute("data-booking") || "";
          if (booking.indexOf("YOUR_") === -1 && booking) { st.textContent = T.okBooking; setTimeout(function () { location.href = booking; }, 1400); }
          else { st.textContent = T.ok; }
          form.reset();
        })
        .catch(function () { st.textContent = T.err; });
    });
  }

  var y = document.getElementById("year"); if (y) y.textContent = new Date().getFullYear();
})();
